import './App.css';
import Usereducer from './component/usereducer';

function App() {
  return (
    <>
     <Usereducer/> 
    </>
  );
}

export default App;
