import React, {useState} from 'react';
import UseEffects from './components/useEffects';
import UseRefs from './components/useRefs';

//useState Hook

function App() {
  const [count, setCount] = useState(() => {
    return 4
  })
  
  const [theme, setTheme] = useState(() => {return 'blue'})

  function decrementCount() {
    setCount(prevCount => prevCount - 1)
  }
  function incrementCount() {
    setCount(prevCount => prevCount + 1)
    setTheme('red')
  }

  /* State works differently when dealing with objects
  const [state, setState] = useState({ count: 4, theme: 'blue' })
  const count = state.count
  const theme = state.theme
  
  function decrementCount() {
    setState( prevState => {
      return { ...prevState, count: prevState.count - 1 }
    })
  }

  function incrementCount() {
    setState(prevCount => prevCount + 1)
  }
  
  */

  return (
    <>
    <h1>useState</h1>
    <button onClick={decrementCount}>-</button>
    <span> {count} </span>
    <span> {theme} </span>
    <button onClick={incrementCount}>+</button>
    <UseEffects/>
    
    <UseRefs/>
    </>
  );
}

export default App;
